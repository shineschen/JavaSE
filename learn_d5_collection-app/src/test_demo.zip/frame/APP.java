package test_demo.frame;

public class APP {
    public static void main(String[] args) {
        HospitalManager h = new HospitalManager();
        h.start();
    }
}
